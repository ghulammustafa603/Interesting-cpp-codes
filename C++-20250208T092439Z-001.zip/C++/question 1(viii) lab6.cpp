#include<iostream>
using namespace std;

int main()
{
int range(0);
for (int a=1; a<=5; ++a){
 range++;
for (int b=1; b<=range; ++b){

cout<<a<<" ";
    }
   cout<<endl;
    }
    return 0;
}