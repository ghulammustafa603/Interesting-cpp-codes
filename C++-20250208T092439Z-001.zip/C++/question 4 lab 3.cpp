#include <iostream>
using namespace std;

int main ()
{
int a;
cout<<"Enter an integer number:\n ";
cin>>a;
if(a/2 && a%2==0)
cout<<"It is an even number\n ";
else
cout<<"It is an odd number\n ";
 system("pause");
 return 0 ;

}



