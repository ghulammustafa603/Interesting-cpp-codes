#include <iostream>
using namespace std ;
int num(string write)
{
	
	return num.length();
}
int main ()
{
	int write;
	cout<<"Enter any words:"<<endl;
	cin>>write;
	num(write);
   
   return 0;
}


