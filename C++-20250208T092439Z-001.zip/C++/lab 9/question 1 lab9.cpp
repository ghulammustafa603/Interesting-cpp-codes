#include <iostream>
#include <string>
using namespace std ;
int main ()
{
 string date;
 cout<<"Enter the date like(date/month/year):\n";
 cin>>date;
cout<<date[0]<<date[1]<<endl<<date[3]<<date[4]<<endl<<date[6]<<date[7]<<date[8]<<date[9];
   return 0;
}


