#include<iostream>
using namespace std;

int main()
{
   
float initial_velocity;
float acceleration;
float final_velocity;
    cout << "please enter initial velocity: \n";
  cin>>initial_velocity;
cout<<"please enter acceleration: \n";
cin>>acceleration;
cout<<"Final velocity= ";
final_velocity=initial_velocity+acceleration;
cout<<final_velocity;
    return 0;
}