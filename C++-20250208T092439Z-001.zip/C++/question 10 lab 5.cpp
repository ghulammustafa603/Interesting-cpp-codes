#include<iostream>
using namespace std;

int main()
{
for (char i=90;i<=90 && i>=65; i--){
if(i!=65 && i!=69 && i!=73 && i!=79 && i!=85)
    cout <<i<<" ";
   }
     return 0;
}