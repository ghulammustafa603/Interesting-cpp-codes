#include<iostream> 
using namespace std; 
int main(){ 	
int range,a; 
	cout<<"Enter the range upto which the loop should run\n"; 
	cin>>range;
 	for(a=1; a<=range;++a){ 		
cout<<a; 	
 	if(a%2==0){ 	 	
	cout<<" is even\n"; } 
	else { 	 
		cout<<" is odd\n"; } 
} return 0;
 } 