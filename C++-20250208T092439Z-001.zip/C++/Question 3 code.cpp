#include<iostream>
using namespace std;

int main()
{
int total_amount;


    cout << "please enter the total amount:\n";
    cin>>total_amount;
    
    cout<<"zakat paid on total amount is ";
    cout<<total_amount*2.5/100;
    
    return 0;
}