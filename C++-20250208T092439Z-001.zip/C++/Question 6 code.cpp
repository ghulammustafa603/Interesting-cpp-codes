#include<iostream>
using namespace std;

int main()
{
   
double a,b,x;

    cout << "please enter the value of a: \n";
  cin>>a;
cout<<"please enter the of b: \n";
cin>>b;

cout<<"x= ";
x=2*(a+b)-2*a*b;
cout<<x;

    return 0;
}