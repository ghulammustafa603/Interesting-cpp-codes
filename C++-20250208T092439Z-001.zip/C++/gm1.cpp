#include <iostream>
using namespace std;

int main ()

{
int marks;
cout<<"Enter your marks "<<endl;
cin>>marks;

if(marks>60)
{
cout<<"congratulation!"<<endl;
cout<<"You have passed "<<endl;}
else if(marks=60){
cout<<"You are just pass "<<endl;
}
else { 
cout<<"You have failed "<<endl;
}
 return 0 ;

}



 






