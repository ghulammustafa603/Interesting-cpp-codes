#include<iostream>
using namespace std;

int main()
{
for (char i=90;i<=90 && i>=65; i--)

    cout <<i<<" ";
    return 0;
}