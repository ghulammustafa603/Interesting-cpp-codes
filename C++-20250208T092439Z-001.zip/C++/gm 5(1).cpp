#include<iostream>
using namespace std;
int main(){
	for(int a=1; a<=10;a++){
		cout<<"Ghulam Mustafa\n";
	}











return 0;
}

