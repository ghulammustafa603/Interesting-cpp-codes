#include<iostream>
using namespace std;
int main(){
int a;
for(a=1; a>0; )
cout<<a;










return 0;
}

