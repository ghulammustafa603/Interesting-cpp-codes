#include <iostream>
using namespace std ;
int main ()
{
int av[10]={6,1,2,3,4,6,7,8,9};
int avg;
avg=av[0]+av[1]+av[2]+av[3]+av[4]+av[5]+av[6]+av[7]+av[8]+av[9]/10;
cout<<"Average="<<avg;
   return 0;
}


