#include<iostream>
using namespace std;

int main()
{
 int num1,num2; float num3; 
 cout<<"please enter two integer and one decimal number: "<<endl; 
 cin>>num1>>num2>>num3; 
 cout<<num1<<" "<<num2<<" "<<num3<<endl;
    return 0;
}