#include<iostream>
using namespace std;
int main(){
for(int x=1; x<=8; x++ )
cout<<x<<"   ";










return 0;
}

