#include<iostream>
 using namespace std; 
int main(){ 	
int range,a; 	
cout<<"Enter the range upto which the loop should run:"; 
	cin>>range; 
	for(a=0; a<=range;++a){ 	

 	
	if(a/5&&a%5==0)
 		cout<<a<<endl; 


 
 } 
return 0; } 