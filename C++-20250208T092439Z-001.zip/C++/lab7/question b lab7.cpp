#include <iostream>
using namespace std ;
int square(int num)
{
return num*num;
}
int main ()
{
	int a(7);
cout<<"The square of 7 is "<<square(a)<<endl;
   system ("PAUSE") ;
   return 0 ;
}


