#include <iostream>
#include<string>
using namespace std;

int main ()
{
string name;
int ID;
int no_of_units;
cout<<"Write your name:\n";
cin>>name;
cout<<"Write your name:\n";
 system("pause");
 return 0 ;

}



