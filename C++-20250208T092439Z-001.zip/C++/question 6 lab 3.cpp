#include <iostream>
using namespace std;

int main ()
{
int a;
cout<<"Enter a number of month in positive integer:\n";
 cin>>a;
 if(a==1)
 cout<<"It is january:\n";
 else if(a==2)
  cout<<"It is febuary:\n";
 else if(a==3)
  cout<<"It is march:\n";
 else if(a==4)
  cout<<"It is april:\n";
 else if(a==5)
  cout<<"It is may:\n";
 else if(a==6)
  cout<<"It is june:\n";
 else if(a==7)
  cout<<"It is july:\n";
else if(a==8)
 cout<<"It is agust:\n";
else if(a==9)
 cout<<"It is septumber:\n";
 else if(a==10)
  cout<<"It is october:\n";
else if(a==11)
 cout<<"It is november:\n";
else if(a==12)
 cout<<"It is december:\n";



 system("pause");
 return 0 ;

}



