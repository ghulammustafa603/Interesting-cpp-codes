#include <iostream>

using namespace std;

int main ()
{
int marks;
cout<<"enter your marks "<<marks<<endl;
cin>>marks;
if(marks>=60)
{
	cout<<"congratulation!"<<marks<<endl;}
cout<<"You have passed "<<marks<<endl;}
else{ 
cout<<"sorry! you have failed "<<endl;}

 return 0 ;

}



