#include <iostream>
using namespace std;

int main ()
{
int a,b;
cout<<"Enter first integer \n";
cin>>a;
cout<<"Enter second integer "<<endl;
cin>>b;
if(a==b)
cout<<"Yes they are equal "<<endl;
else 
cout<<"They are unequal "<<endl;
 system("pause");
 return 0 ;

}



