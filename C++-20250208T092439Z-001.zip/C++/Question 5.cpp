#include<iostream>
using namespace std;

int main()
{
   
float distance;
float time;
float speed;
    cout << "please enter the distance: \n";
  cin>>distance;
cout<<"please enter the time: \n";
cin>>time;
cout<<"speed= ";
speed=distance/time;
cout<<speed;
    return 0;
}